//
//  BrewerCell.swift
//  BrewList
//
//  Created by user180592 on 12/1/20.
//

import UIKit

class BrewerCell: UITableViewCell
{
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var subLabel: UILabel!
    @IBOutlet var starsLabel: UILabel!
}
